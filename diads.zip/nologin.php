<?php unset($_COOKIE); setcookie("login","false"); setcookie("vartime", 1); header("Location: index.php"); ?>
<!-- logout -->

